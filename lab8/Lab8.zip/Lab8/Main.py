# -*- coding: utf-8 -*-
"""
Created on Wed Dec 16 17:19:13 2020

@author: yahya
"""

from Prism import *


r1 = Rectangle(10, 5)
t1 = Triangle(6)
s1 = Square(5)
tp1 = TrianglePrism( 6, 12)
sp1 = SquarePyramid(5)
print('Rectangle:', r1)
print('---')
print('Triangle:', t1)
print('---')
print('Square:', s1)
print('---')
print('Triangle Prism:', tp1)
print('---')
print('Square Pyramid:', sp1)

