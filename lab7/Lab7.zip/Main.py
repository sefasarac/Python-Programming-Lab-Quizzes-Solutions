# -*- coding: utf-8 -*-
"""
Created on Tue Dec  8 20:04:45 2020

@author: yahya
"""


from Shapes import *

s1 = Shape('Shape1', 'red', 'dotted', 5 )
r1 = Rectangle(10, 5,'Rect1','red','dotted', 5 )
c1 = Circle(8,'circ1','blue','dotdash', 2 )
t1 = Triangle(3, 4, 6,'tria1','green','solid', 4)
sq1 = Square(5, 'squ1','orange','dashed', 4)


print(s1)
print('**********')
print(r1)
print('**********')
print(c1)
print('**********')
print(t1)
print('**********')
print(sq1)
